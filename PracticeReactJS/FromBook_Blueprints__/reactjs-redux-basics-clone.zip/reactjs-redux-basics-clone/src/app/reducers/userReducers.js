const user = (state = {        name: "Mike",        age: 2    }, action) =>     {
    switch (action.type) {
        case "age":
            state = {...state,
                age: action.v
            };
        case "SET_NAME":
            state = {...state,
                name: action.payload
            };
            break;
    }
    return state;
};

export default user;