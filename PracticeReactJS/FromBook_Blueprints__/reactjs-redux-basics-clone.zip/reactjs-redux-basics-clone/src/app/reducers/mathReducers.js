const mathR = (state = {
    result: 0,
    history: []
}, action) => {
    switch(action.type) {
        case "A":
            state = {
                ...state,
                result: state.result + action.v,
                history: [...state.history, action.v]

            };
            break;
    }
    return state;
};

export default mathR;