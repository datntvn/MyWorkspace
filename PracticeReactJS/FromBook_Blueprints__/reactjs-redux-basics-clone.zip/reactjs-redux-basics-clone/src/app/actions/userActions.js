export function setName(name) {
	// 1.
	// return {
	// 	type: "SET_NAME",
	// 	payload: name
	// };
	// 2.
	// return dispatch => {
	// 	setTimeout(() => {
	// 		dispatch({
	// 			type: "name",
	// 			str: n
	// 		});
	// 	}, 2000);
	// };
	// 3.
	return {
		type: "SET_NAME",
		payload: new Promise((resolve, reject) => {
			setTimeout(() => {
				resolve(name);
			},2000);
		})
	};

}