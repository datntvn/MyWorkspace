import React from "react";
import {render} from "react-dom";

import App from './components/App';


import { createStore } from "redux";
import { combineReducers } from "redux";
import { applyMiddleware } from "redux";
import { Provider } from "react-redux";

const initState = {
    result: 0,
    history: []
};

const mathR = (state = initState, action) => {
    switch(action.type) {
        case "A":
            state = {
                ...state,
                result: state.result + action.v,
                history: [...state.history, action.v]

            };
            break;
    }
    return state;
};

const user = (state = {        name: "M",        age: 2    }, action) =>     {
    switch (action.type) {
        case "age":
            state = {...state,
                age: action.v
            };
        case "name":
            state = {...state,
                name: action.str
            };
            break;
    }
    return state;
};


const store = createStore(combineReducers({math: mathR, user: user}));
store.subscribe(() => {
    console.log("v: ", store.getState());
});

render(
    <Provider store={store}>
    <App />
    </Provider>
    , window.document.getElementById('app'));
